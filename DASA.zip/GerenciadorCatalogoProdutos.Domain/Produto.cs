﻿namespace GerenciadorCatalogoProdutos.Domain
{
    public class Produto
    {
        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public decimal Preco { get; set; }
        public int CategoriaId { get; set; }        
        public int ProprietarioId { get; set; }
    }

}
