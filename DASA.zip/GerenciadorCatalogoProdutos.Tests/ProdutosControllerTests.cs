﻿using GerenciadorCatalogoProdutos.Domain;
using GerenciadorCatalogoProdutos.Infrastructure;
using GerenciadorCatalogoProdutos.Infrastructure.Services;
using GerenciadorCatalogoProdutos.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciadorCatalogoProdutos.Tests
{
    public class ProdutosControllerTests
    {
        private readonly GCProdutosDbContext _context;
        private readonly ILogger<ProdutosController> _logger;
        private readonly Mock<IRabbitMQService> _rabbitMQService;

        public ProdutosControllerTests()
        {
            var options = new DbContextOptionsBuilder<GCProdutosDbContext>()
                .UseInMemoryDatabase(databaseName: "Teste Produtos na Base de Dados")
                .Options;

            _context = new GCProdutosDbContext(options);
            _logger = Mock.Of<ILogger<ProdutosController>>();
            _rabbitMQService = new Mock<IRabbitMQService>();
        }

        [Fact]
        public async Task PostProduto_CreatesProduto_ReturnsCreatedAtActionResult()
        {
            // Arrange
            var controller = new ProdutosController(_context, _logger, _rabbitMQService.Object);
            var produto = new Produto
            {
                Titulo = "Produto 1",
                Descricao = "Descricao 1",
                Preco = 10.0m,
                ProprietarioId = 1
            };

            // Act
            var result = await controller.PostProduto(produto);

            // Assert
            var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result);
            Assert.Equal("GetProduto", createdAtActionResult.ActionName);
            Assert.Equal(produto, createdAtActionResult.Value);
        }

        [Fact]
        public async Task GetProduto_ReturnsProduto()
        {
            // Arrange
            var cache = new Mock<IMemoryCache>();
            var produto = new Produto
            {
                Titulo = "Produto 1",
                Descricao = "Descricao 1",
                ProprietarioId = 1
            };

            _context.Produtos.Add(produto);
            await _context.SaveChangesAsync();

            var controller = new ProdutosController(_context, _logger, _rabbitMQService.Object);

            // Act
            var result = await controller.GetProduto(produto.Id);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedProduto = Assert.IsType<Produto>(okResult.Value);
            Assert.Equal(produto.Titulo, returnedProduto.Titulo);
        }

        [Fact]
        public async Task PutProduto_UpdatesProduto_ReturnsNoContent()
        {
            // Arrange
            var produto = new Produto
            {
                Titulo = "Produto 1",
                Descricao = "Descricao 1",
                ProprietarioId = 1
            };

            _context.Produtos.Add(produto);
            await _context.SaveChangesAsync();

            var controller = new ProdutosController(_context, _logger, _rabbitMQService.Object);
            var updatedProduto = new Produto
            {
                Id = produto.Id,
                Titulo = "Produto Atualizado",
                Descricao = "Descricao Atualizada",
                ProprietarioId = 1
            };

            // Act
            var result = await controller.PutProduto(produto.Id, updatedProduto);

            // Assert
            Assert.IsType<NoContentResult>(result);
            var produtoFromDb = await _context.Produtos
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.Id == produto.Id);
            Assert.Equal("Produto Atualizado", produtoFromDb.Titulo);
        }

        [Fact]
        public async Task DeleteProduto_DeletesProduto_ReturnsNoContent()
        {
            // Arrange
            var produto = new Produto
            {
                Titulo = "Produto 1",
                Descricao = "Descricao 1",
                ProprietarioId = 1
            };

            _context.Produtos.Add(produto);
            await _context.SaveChangesAsync();

            var controller = new ProdutosController(_context, _logger, _rabbitMQService.Object);

            // Act
            var result = await controller.DeleteProduto(produto.Id);

            // Assert
            Assert.IsType<NoContentResult>(result);
            var produtoFromDb = await _context.Produtos.FindAsync(produto.Id);
            Assert.Null(produtoFromDb);
        }
    }    
}
