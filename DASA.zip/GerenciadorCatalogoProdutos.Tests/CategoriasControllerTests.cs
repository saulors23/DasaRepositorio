﻿using GerenciadorCatalogoProdutos.Domain;
using GerenciadorCatalogoProdutos.Infrastructure;
using GerenciadorCatalogoProdutos.Infrastructure.Services;
using GerenciadorCatalogoProdutos.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Moq;

namespace GerenciadorCatalogoProdutos.Tests
{
    public class CategoriasControllerTests
    {
        private readonly GCProdutosDbContext _context;
        private readonly ILogger<CategoriasController> _logger;
        private readonly Mock<IRabbitMQService> _rabbitMQService;

        public CategoriasControllerTests()
        {
            var options = new DbContextOptionsBuilder<GCProdutosDbContext>()
                .UseInMemoryDatabase(databaseName: "Teste Categorias na Base de Dados")
                .Options;

            _context = new GCProdutosDbContext(options);
            _logger = Mock.Of<ILogger<CategoriasController>>();
            _rabbitMQService = new Mock<IRabbitMQService>();
        }

        [Fact]
        public async Task PostCategoria_CreatesCategoria_ReturnsCreatedAtActionResult()
        {
            // Arrange
            var controller = new CategoriasController(_context, _logger, _rabbitMQService.Object);
            var categoria = new Categoria
            {
                Titulo = "Categoria 1",
                Descricao = "Descricao 1",
                ProprietarioId = 1
            };

            // Act
            var result = await controller.PostCategoria(categoria);

            // Assert
            var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result);
            Assert.Equal("GetCategoria", createdAtActionResult.ActionName);
            Assert.Equal(categoria, createdAtActionResult.Value);
        }

        [Fact]
        public async Task GetCategoria_ReturnsCategoria()
        {
            // Arrange
            var cache = new Mock<IMemoryCache>();
            var categoria = new Categoria
            {
                Titulo = "Categoria 1",
                Descricao = "Descricao 1",
                ProprietarioId = 1
            };

            _context.Categorias.Add(categoria);
            await _context.SaveChangesAsync();

            var controller = new CategoriasController(_context, _logger, _rabbitMQService.Object);

            // Act
            var result = await controller.GetCategoria(categoria.Id);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedCategoria = Assert.IsType<Categoria>(okResult.Value);
            Assert.Equal(categoria.Titulo, returnedCategoria.Titulo);
        }

        [Fact]
        public async Task PutCategoria_UpdatesCategoria_ReturnsNoContent()
        {
            // Arrange
            var categoria = new Categoria
            {
                Titulo = "Categoria 1",
                Descricao = "Descricao 1",
                ProprietarioId = 1
            };

            _context.Categorias.Add(categoria);
            await _context.SaveChangesAsync();

            var controller = new CategoriasController(_context, _logger, _rabbitMQService.Object);
            var updatedCategoria = new Categoria
            {
                Id = categoria.Id,
                Titulo = "Categoria Atualizada",
                Descricao = "Descricao Atualizada",
                ProprietarioId = 1
            };

            // Act
            var result = await controller.PutCategoria(categoria.Id, updatedCategoria);

            // Assert
            Assert.IsType<NoContentResult>(result);
            var categoriaFromDb = await _context.Categorias
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.Id == categoria.Id);
            Assert.Equal("Categoria Atualizada", categoriaFromDb.Titulo);
        }

        [Fact]
        public async Task DeleteCategoria_DeleteCategoria_ReturnsNoContent()
        {
            // Arrange
            var categoria = new Categoria
            {
                Titulo = "Categoria 1",
                Descricao = "Descricao 1",
                ProprietarioId = 1
            };

            _context.Categorias.Add(categoria);
            await _context.SaveChangesAsync();

            var controller = new CategoriasController(_context, _logger, _rabbitMQService.Object);

            // Act
            var result = await controller.DeleteCategoria(categoria.Id);

            // Assert
            Assert.IsType<NoContentResult>(result);
            var categoriaFromDb = await _context.Categorias.FindAsync(categoria.Id);
            Assert.Null(categoriaFromDb);
        }
    }
}
