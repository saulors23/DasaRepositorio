﻿namespace GerenciadorCatalogoProdutos.Infrastructure.Services
{
    public interface IRabbitMQService
    {
        void PublishCatalogChangeMessage(CatalogChangeEvent catalogChangeEvent);
        void Dispose();
    }
}
