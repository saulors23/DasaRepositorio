﻿using RabbitMQ.Client;
using System.Text.Json;
using System.Text;
using GerenciadorCatalogoProdutos.Infrastructure.Services;

namespace GerenciadorCatalogoProdutos.Infrastructure.Services
{
    public class RabbitMQService : IRabbitMQService, IDisposable
    {
        private readonly IConnection _connection;
        private readonly IModel _channel;        

        public RabbitMQService(string hostName)
        {
            var factory = new ConnectionFactory() { HostName = "localhost", Port = 5672 };
            _connection = factory.CreateConnection();
            _channel = _connection.CreateModel();

            _channel.QueueDeclare(queue: "catalog-emit",
                                  durable: false,
                                  exclusive: false,
                                  autoDelete: false,
                                  arguments: null);
        }

        public void PublishCatalogChangeMessage(CatalogChangeEvent catalogChangeEvent)
        {
            var message = JsonSerializer.Serialize(catalogChangeEvent);
            var body = Encoding.UTF8.GetBytes(message);

            _channel.BasicPublish(exchange: "",
                                  routingKey: "catalog-emit",
                                  basicProperties: null,
                                  body: body);
        }

        public void Dispose()
        {
            _channel.Dispose();
            _connection.Dispose();
        }
    }
}
