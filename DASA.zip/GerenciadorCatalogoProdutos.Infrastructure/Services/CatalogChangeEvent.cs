﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GerenciadorCatalogoProdutos.Infrastructure.Services;

namespace GerenciadorCatalogoProdutos.Infrastructure.Services
{
    public class CatalogChangeEvent
    {
        public int IdEntidade { get; set; }
        public string TipoEvento { get; set; }
        public DateTime DataEvento { get; set; }
    }
}
