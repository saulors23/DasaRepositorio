﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using System.Text.Json;

namespace GerenciadorCatalogoProdutos.Infrastructure.Services
{
    public class CatalogEventConsumer : BackgroundService
    {
        private readonly ILogger<CatalogEventConsumer> _logger;
        private readonly IServiceProvider _serviceProvider;
        private readonly RabbitMQService _rabbitMQService;

        public CatalogEventConsumer(
            IServiceProvider serviceProvider,
            ILogger<CatalogEventConsumer> logger,
            RabbitMQService rabbitMQService)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
            _rabbitMQService = rabbitMQService;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var factory = new ConnectionFactory() { HostName = "localhost" };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.QueueDeclare(queue: "catalog-emit",
                                     durable: false,
                                     exclusive: false,
                                     autoDelete: false,
                                     arguments: null);

                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += async (model, ea) =>
                {
                    var body = ea.Body.ToArray();
                    var message = Encoding.UTF8.GetString(body);
                    
                    await ProcessMessage(message);

                    _logger.LogInformation($"Mensagem recebida: {message}");
                };
                channel.BasicConsume(queue: "catalog-emit",
                                     autoAck: true,
                                     consumer: consumer);

                while (!stoppingToken.IsCancellationRequested)
                {
                    await Task.Delay(1000, stoppingToken);
                }
            }
        }

        private async Task ProcessMessage(string message)
        {
            // Implementar lógica para processar eventos recebidos do RabbitMQ
            try
            {                
                var catalogEvent = JsonSerializer.Deserialize<CatalogChangeEvent>(message);
                
                using (var scope = _serviceProvider.CreateScope())
                {
                    var service = scope.ServiceProvider.GetRequiredService<ICatalogEventService>();
                    await service.ProcessCatalogEvent(catalogEvent);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Erro ao processar mensagem do RabbitMQ: {ex.Message}");
            }
        }
    }
}
