﻿using GerenciadorCatalogoProdutos.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace GerenciadorCatalogoProdutos.Infrastructure
{
    public class GCProdutosDbContext : DbContext
    {
        private readonly IMemoryCache _cache;

        public GCProdutosDbContext(DbContextOptions<GCProdutosDbContext> options, IMemoryCache cache)
            : base(options)
        {
            _cache = cache;
        }
        public DbSet<Produto> Produtos { get; set; }
        public DbSet<Categoria> Categorias { get; set; }

        public GCProdutosDbContext(DbContextOptions<GCProdutosDbContext> options)
            : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Produto>(entity =>
            {
                entity.Property(p => p.Preco).HasPrecision(18,2);
            });

            modelBuilder.Entity<Categoria>(entity =>
            {
                entity.Property(c => c.Titulo).IsRequired().HasMaxLength(100);
                entity.Property(c => c.Descricao).HasMaxLength(250);
            });
        }

        public async Task<List<Produto>> GetProdutosCachedAsync()
        {
            if (!_cache.TryGetValue("ProdutosCache", out List<Produto> produtos))
            {
                produtos = await Produtos.ToListAsync();
                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(10)); 
                _cache.Set("ProdutosCache", produtos, cacheEntryOptions);
            }
            return produtos;
        }

        public async Task<List<Categoria>> GetCategoriasCachedAsync()
        {
            if (!_cache.TryGetValue("CategoriasCache", out List<Categoria> categorias))
            {
                categorias = await Categorias.ToListAsync();
                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(10));
                _cache.Set("CategoriasCache", categorias, cacheEntryOptions);
            }
            return categorias;
        }
    }
}
