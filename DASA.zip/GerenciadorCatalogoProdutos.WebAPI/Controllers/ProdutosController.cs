﻿using GerenciadorCatalogoProdutos.Domain;
using GerenciadorCatalogoProdutos.Infrastructure;
using GerenciadorCatalogoProdutos.Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace GerenciadorCatalogoProdutos.WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProdutosController : ControllerBase
    {
        private readonly GCProdutosDbContext _context;
        private readonly ILogger<ProdutosController> _logger;
        private readonly IRabbitMQService _rabbitMQService;

        public ProdutosController(GCProdutosDbContext context, ILogger<ProdutosController> logger,
            IRabbitMQService rabbitMQService)
        {
            _context = context;
            _logger = logger;
            _rabbitMQService = rabbitMQService;
        }

        #region Adiciona Produto
        [HttpPost]
        public async Task<IActionResult> PostProduto(Produto produto)
        {
            try
            {
                _context.Produtos.Add(produto);
                await _context.SaveChangesAsync();

                var catalogEvent = new CatalogChangeEvent
                {
                    TipoEvento = "NovoProduto",
                    IdEntidade = produto.Id,
                    DataEvento = DateTime.UtcNow
                };
                _rabbitMQService.PublishCatalogChangeMessage(catalogEvent);

                return CreatedAtAction(nameof(GetProduto), new { id = produto.Id }, produto);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Erro ao adicionar produto: {ex.Message}");
                return StatusCode(500, "Erro interno ao processar a requisição");
            }
        }
        #endregion

        #region Lista Produto por Id
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduto(int id)
        {
            var produto = await _context.Produtos.FindAsync(id);
            if (produto == null)
            {
                return NotFound();
            }
            return Ok(produto);
        }
        #endregion

        #region Altera Produto por Id
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduto(int id, Produto produto)
        {
            if (id != produto.Id)
            {
                return BadRequest();
            }

            var existingProduto = await _context.Produtos.FindAsync(id);
            if (existingProduto == null)
            {
                return NotFound();
            }

            _context.Entry(existingProduto).State = EntityState.Detached;
            _context.Entry(produto).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();

                var catalogEvent = new CatalogChangeEvent
                {
                    TipoEvento = "AtualizaProduto",
                    IdEntidade = produto.Id,
                    DataEvento = DateTime.UtcNow
                };
                _rabbitMQService.PublishCatalogChangeMessage(catalogEvent);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Erro ao atualizar produto: {ex.Message}");
                return StatusCode(500, "Erro interno ao processar a requisição");
            }
        }
        #endregion

        #region Exclui Produto por Id
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduto(int id)
        {
            var produto = await _context.Produtos.FindAsync(id);
            if (produto == null)
            {
                return NotFound();
            }

            _context.Produtos.Remove(produto);
            await _context.SaveChangesAsync();

            var catalogEvent = new CatalogChangeEvent
            {
                TipoEvento = "ExcluiProduto",
                IdEntidade = id,
                DataEvento = DateTime.UtcNow
            };
            _rabbitMQService.PublishCatalogChangeMessage(catalogEvent);

            return NoContent();
        }
        #endregion
    }
}
