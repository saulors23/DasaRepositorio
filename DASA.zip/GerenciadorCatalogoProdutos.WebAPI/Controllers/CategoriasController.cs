﻿using GerenciadorCatalogoProdutos.Domain;
using GerenciadorCatalogoProdutos.Infrastructure;
using GerenciadorCatalogoProdutos.Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;

namespace GerenciadorCatalogoProdutos.WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoriasController : ControllerBase
    {
        private readonly GCProdutosDbContext _context;
        private readonly ILogger<CategoriasController> _logger;
        private readonly IRabbitMQService _rabbitMQService;

        public CategoriasController(GCProdutosDbContext context, ILogger<CategoriasController> logger,
            IRabbitMQService rabbitMQService)
        {
            _context = context;
            _logger = logger;
            _rabbitMQService = rabbitMQService;
        }

        #region Adiciona Categoria
        [HttpPost]
        public async Task<IActionResult> PostCategoria(Categoria categoria)
        {
            try
            {
                _context.Categorias.Add(categoria);
                await _context.SaveChangesAsync();

                var catalogEvent = new CatalogChangeEvent
                {
                    TipoEvento = "NovaCategoria",
                    IdEntidade = categoria.Id,
                    DataEvento = DateTime.UtcNow
                };
                _rabbitMQService.PublishCatalogChangeMessage(catalogEvent);

                return CreatedAtAction(nameof(GetCategoria), new { id = categoria.Id }, categoria);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Erro ao adicionar categoria: {ex.Message}");
                return StatusCode(500, "Erro interno ao processar a requisição");
            }
        }
        #endregion

        #region Lista Categoria por Id
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCategoria(int id)
        {
            var categoria = await _context.Categorias.FindAsync(id);
            if (categoria == null)
            {
                return NotFound();
            }
            return Ok(categoria);
        }
        #endregion

        #region Altera Categoria por Id
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCategoria(int id, Categoria categoria)
        {
            if (id != categoria.Id)
            {
                return BadRequest();
            }

            var existingCategoria = await _context.Categorias.FindAsync(id);
            if (existingCategoria == null)
            {
                return NotFound();
            }

            _context.Entry(existingCategoria).State = EntityState.Detached;
            _context.Entry(categoria).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();

                var catalogEvent = new CatalogChangeEvent
                {
                    TipoEvento = "AtualizaCategoria",
                    IdEntidade = categoria.Id,
                    DataEvento = DateTime.UtcNow
                };
                _rabbitMQService.PublishCatalogChangeMessage(catalogEvent);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Erro ao atualizar categoria: {ex.Message}");
                return StatusCode(500, "Erro interno ao processar a requisição");
            }

        }
        #endregion

        #region Exclui Categoria
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategoria(int id)
        {
            var categoria = await _context.Categorias.FindAsync(id);
            if (categoria == null)
            {
                return NotFound();
            }

            _context.Categorias.Remove(categoria);
            await _context.SaveChangesAsync();

            var catalogEvent = new CatalogChangeEvent
            {
                TipoEvento = "ExcluiCategoria",
                IdEntidade = id,
                DataEvento = DateTime.UtcNow
            };
            _rabbitMQService.PublishCatalogChangeMessage(catalogEvent);

            return NoContent();
        }
        #endregion
    }
}
