using GerenciadorCatalogoProdutos.Infrastructure;
using GerenciadorCatalogoProdutos.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Microsoft.OpenApi.Models;
using System.Linq;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<GCProdutosDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("GCProdutosConnection")));

builder.Services.AddScoped<IRabbitMQService>(sp =>
{
    var configuration = sp.GetRequiredService<IConfiguration>();
    var hostName = configuration.GetSection("RabbitMQ:HostName").Value;
    return new RabbitMQService(hostName);
});

//builder.Services.AddScoped<IRabbitMQService, RabbitMQService>();
builder.Services.AddControllers().AddNewtonsoftJson();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", 
        new OpenApiInfo { 
            Title = $"Gerenciador Catalogo Produtos API ", 
            Version = "v1" });
});

var app = builder.Build();

app.UseRouting();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Gerenciador Catalogo Produtos API v1");        
    });
}
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
    endpoints.MapGet("/endpoints", async context =>
    {
        var data = app.Services.GetService<EndpointDataSource>();
        await context.Response.WriteAsync(
            string.Join("\n", data.Endpoints.Select(e => e.DisplayName))
        );
    });
});

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();